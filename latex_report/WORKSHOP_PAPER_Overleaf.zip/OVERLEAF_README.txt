WORKSHOP PAPER — OVERLEAF SOURCE PROJECT

Upload this ZIP as a new Overleaf project.
Main document: main.tex
Compiler: pdfLaTeX
All required sections, tables, figures, bibliography and local styles
are included. Python and the original experiment repository are not
required for compilation. Change the compiler in project settings.

The complete editable project, evidence and chart-generation scripts
are published in latex_report/ in the GitHub repository:
https://github.com/VasantatiChitraksh/BTP_Aegis-Perception

The workshop main.tex combines the paper-only wrappers, with the
tested OT1 font option. All scientific sections and figures retain
their original bytes. The supplied Workshop_Paper.pdf in GitHub
remains the canonical PDF; compiler versions can change rendering.

Overleaf upload instructions:
https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
