BTP_REPORT — OVERLEAF SOURCE PROJECT

Upload this ZIP as a new Overleaf project.
Main document: main.tex
Compiler: XeLaTeX
All required sections, tables, figures, bibliography and local styles
are included. Python and the original experiment repository are not
required for compilation. Change the compiler in project settings.

The complete editable project, evidence and chart-generation scripts
are published in latex_report/ in the GitHub repository:
https://github.com/VasantatiChitraksh/BTP_Aegis-Perception

Overleaf upload instructions:
https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
